Mind Matters - self-contained website

Open index.html in a modern web browser. All six original images are embedded directly in the HTML, so no separate images folder is required. An internet connection is only needed to load the Google Fonts.
